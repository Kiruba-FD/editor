Froala WYSIWYG Editor
================

Froala WYSIWYG Editor can be used for:

- Non Commercial purposes under Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License (http://creativecommons.org/licenses/by-nc-nd/4.0/).

- Commercial purposes under Froala License Agreement (http://editor.froala.com/license).
